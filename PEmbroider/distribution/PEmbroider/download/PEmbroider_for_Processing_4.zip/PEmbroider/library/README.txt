The lib folder:
In case your Library requires 3rd party libraries, which need to be 
added to the distribution, put them into the lib folder. 
These 3rd party libraries will be added to your distribution and are 
located next to your Library's jar file.
This does not apply to .jar files that are considered core processing libraries.